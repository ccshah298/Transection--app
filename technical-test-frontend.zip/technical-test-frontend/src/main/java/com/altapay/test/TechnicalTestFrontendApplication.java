package com.altapay.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechnicalTestFrontendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechnicalTestFrontendApplication.class, args);
	}

}
