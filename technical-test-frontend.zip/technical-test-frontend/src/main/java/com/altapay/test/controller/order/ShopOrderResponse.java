package com.altapay.test.controller.order;

public class ShopOrderResponse {
}
