package com.altapay.test.model;

public enum TransactionType {
	RESERVE, CAPTURE, REFUND, RELEASE
}
