package com.altapay.test.persistance;

import com.altapay.test.model.ShopOrder;

import java.util.Optional;

public interface IShopOrderRepository extends IRepository<ShopOrder> {

}
